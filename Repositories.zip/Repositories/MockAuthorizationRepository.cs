﻿using RA_Delegation.Interfaces;

namespace RA_Delegation.Repositories
{
    public class MockAuthorizationRepository : IAuthorizationRepository
    {
        public Task<List<string>> GetAllowedCompanyNumbersAsync(string userId)
        {
            // סימולציה – לפי userId או כללית
            var allowed = new List<string> { "1111", "2222" };
            return Task.FromResult(allowed);
        }
    }
}