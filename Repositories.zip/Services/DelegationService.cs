﻿using RA_Delegation.Models;

using RA_Delegation.Interfaces;

namespace RA_Delegation.Services

{

    public class DelegationService : IDelegationService

    {

        private readonly IAuthorizationRepository _authorizationRepository;

        public DelegationService(IAuthorizationRepository authorizationRepository)

        {

            _authorizationRepository = authorizationRepository;

        }

        /// <summary>

        /// Retrieves a list of companies that the user is authorized to access.

        /// 

        /// Steps:

        /// 1. Simulate external data retrieval.

        /// 2. Normalize permissions (remove "User").

        /// 3. Perform validation against the database:

        ///    Query MongoDB collection to cross-check authorized company numbers.

        /// </summary>

        public async Task<List<NormalizedCompany>> GetUserDelegationsAsync(string userId)

        {

            // Simulated external response (e.g., from external system or API)

            var externalResponse = new List<ExternalCompany>

            {

                new ExternalCompany

                {

                    CompanyName = "Alpha",

                    CompanyNumber = "1111",

                    Permissions = "Admin/User/ViewOnly"

                },

                new ExternalCompany

                {

                    CompanyName = "Beta",

                    CompanyNumber = "2222",

                    Permissions = "User"

                }

            };

            // Normalize permissions by removing "User"

            var normalized = externalResponse

                .Where(d => !string.IsNullOrWhiteSpace(d.Permissions))

                .Select(d => new NormalizedCompany

                {

                    CompanyName = d.CompanyName,

                    CompanyNumber = d.CompanyNumber,

                    Permissions = NormalizePermissions(d.Permissions)

                })

                .ToList();

            // Query MongoDB for allowed company numbers for this user

            var allowedCompanyNumbers = await _authorizationRepository.GetAllowedCompanyNumbersAsync(userId);

            // Filter only companies that the user is authorized for

            var filtered = normalized

                .Where(d => allowedCompanyNumbers.Contains(d.CompanyNumber))

                .ToList();

            return filtered;

        }

        /// <summary>

        /// Removes "User" from the permissions string and returns a cleaned, distinct list.

        /// </summary>

        private string NormalizePermissions(string permissions)

        {

            return string.Join(

                "/",

                permissions

                    .Split('/', StringSplitOptions.RemoveEmptyEntries)

                    .Select(p => p.Trim())

                    .Where(p => p != "User")

                    .Distinct()

            );

        }

    }

}

