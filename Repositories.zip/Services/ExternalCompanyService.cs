﻿using System;

using System.Collections.Generic;

using System.Net.Http;

using System.Text.Json;

using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using RA_Delegation.Interfaces;
using RA_Delegation.Models;

public class ExternalCompanyService : IExternalCompanyService

{

    private readonly HttpClient _httpClient;

    private readonly IConfiguration _configuration;

    public ExternalCompanyService(HttpClient httpClient, IConfiguration configuration)

    {

        _httpClient = httpClient;

        _configuration = configuration;

    }

    public async Task<List<ExternalCompany>> GetCompaniesAsync(string userId, bool useMock = false)

    {

        if (useMock)

        {

            return new List<ExternalCompany>

            {

                new ExternalCompany { CompanyName = "Alpha", CompanyNumber = "1111", Permissions = "Admin/User/ViewOnly" },

                new ExternalCompany { CompanyName = "Beta", CompanyNumber = "2222", Permissions = "User" }

            };

        }

        try

        {

            var baseUrl = _configuration["ExternalApi:BaseUrl"];

            var url = $"{baseUrl}/companies?userId={userId}";

            var response = await _httpClient.GetAsync(url);

            response.EnsureSuccessStatusCode();

            var json = await response.Content.ReadAsStringAsync();

            var companies = JsonSerializer.Deserialize<List<ExternalCompany>>(json, new JsonSerializerOptions

            {

                PropertyNameCaseInsensitive = true

            });

            return companies ?? new List<ExternalCompany>();

        }

        catch (Exception ex)

        {

            Console.WriteLine($"Error fetching external data: {ex.Message}");

            return new List<ExternalCompany>();

        }

    }

}

