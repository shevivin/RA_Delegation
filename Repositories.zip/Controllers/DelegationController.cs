﻿using Microsoft.AspNetCore.Mvc;
using System;

using System.Collections.Generic;

using System.Net.Http;

using System.Text.Json;

using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using RA_Delegation.Interfaces;
using RA_Delegation.Models;

namespace RA_Delegation.Controllers

{

    [ApiController]

    [Route("api/[controller]")]

    public class DelegationController : ControllerBase

    {

        private readonly IExternalCompanyService _service;

        public CompanyController(IExternalCompanyService service)
        {
            _service = service;
        }

        [HttpGet("external")]
        public async Task<IActionResult> GetExternalCompanies([FromQuery] string userId, [FromQuery] bool mock = false)
        {
            var companies = await _service.GetCompaniesAsync(userId, mock);
            return Ok(companies);
        }
    }

}


 