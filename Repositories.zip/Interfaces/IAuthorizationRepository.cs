﻿namespace RA_Delegation.Interfaces
{
    public interface IAuthorizationRepository
    {
        Task<List<string>> GetAllowedCompanyNumbersAsync(string userId);
    }
}
