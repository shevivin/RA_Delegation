﻿using RA_Delegation.Models;

namespace RA_Delegation.Interfaces
{
    public interface IDelegationService
    {
        Task<List<NormalizedCompany>> GetUserDelegationsAsync(string userId);
    }
}
