﻿using RA_Delegation.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RA_Delegation.Interfaces
{   
    public interface IExternalCompanyService
    {
        Task<List<ExternalCompany>> GetCompaniesAsync(string userId, bool useMock = false);
    }
}
