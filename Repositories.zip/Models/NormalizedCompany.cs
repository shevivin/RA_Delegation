﻿namespace RA_Delegation.Models
{
    public class NormalizedCompany
    {
        public string CompanyName { get; set; }
        public string CompanyNumber { get; set; }
        public string Permissions { get; set; }//אילו שינויים צריך לערוך על מנת לנרמל את האוביקט
    }
}
