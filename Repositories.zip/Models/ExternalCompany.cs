﻿namespace RA_Delegation.Models
{
    public class ExternalCompany
    {
        public string CompanyName { get; set; }
        public string CompanyNumber { get; set; }
        public string Permissions { get; set; }
    }
}
