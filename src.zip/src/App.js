import React from 'react';
import CompanyList from './components/CompanyList';
 
function App() {
  return (
<div className="App">
<CompanyList userId="123456789" />
</div>
  );
}
 
export default App;